import 'package:flutter/material.dart';

const loc1 = 'assets/images/location1.svg';
const loc2 = 'assets/images/location2.svg';
const loc3 = 'assets/images/location3.svg';
