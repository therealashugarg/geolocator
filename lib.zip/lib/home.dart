// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:getmygps/login.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
          child: GestureDetector(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => LoginPage()));
              },
              child: Container(
                height: 40,
                width: 100,
                child: Center(
                    child: Text(
                  'Logout',
                  style: TextStyle(color: Colors.white),
                )),
                decoration: BoxDecoration(color: Color(0XFF6C63FF),borderRadius: BorderRadius.circular(8)),
              ))),
    );
  }
}
